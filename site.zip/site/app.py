from flask import Flask,render_template, request

app = Flask(__name__)

#rota raiz
@app.route('/')
def Index():
    return render_template('formulario.html')

@app.route('/resultado', methods=['POST'])
def resultado():
    nome = request.form.get('nome')
    email = request.form.get('email')
    curso = request.form.get('curso')
    sexo = request.form.get('sexo')
    turno = request.form.getlist('turno')
    observacoes = request.form.get('observacoes')

    return render_template('resultado.html',
    nome = nome,
    email = email,
    curso = curso,
    sexo = sexo,
    turno = turno,
    observacoes = observacoes

    )

if __name__ == '__main__':
    app.run(debug=True)